// OpenPath main JS - animations, modal, lead capture
// Initialize AOS (Animate on Scroll)
document.addEventListener('DOMContentLoaded', function() {
  if (window.AOS) {
    AOS.init({ once: false, duration: 700, easing: 'ease-out-cubic', offset: 120 });
  }
});

// GSAP entry motion
window.addEventListener('load', function() {
  if (window.gsap) {
    gsap.from('.hero-animate', { opacity: 0, y: 40, duration: 0.9, stagger: 0.15, ease: 'power2.out' });
    gsap.from('.logo-float', { y: -10, duration: 1.2, ease: 'sine.inOut', repeat: -1, yoyo: true });
  }
});

// Modal logic: show on timers, scroll depth, and exit intent (max 3 per session)
(function() {
  const backdrop = document.querySelector('#leadBackdrop');
  const modal = document.querySelector('#leadModal');
  const openBtns = document.querySelectorAll('[data-open-lead]');
  const closeBtns = document.querySelectorAll('[data-close-lead]');
  const key = 'openpath_lead_shown';

  const showModal = () => {
    const count = parseInt(localStorage.getItem(key) || '0', 10);
    if (count >= 3) return;
    backdrop.classList.add('show');
    modal.classList.add('show');
    localStorage.setItem(key, String(count + 1));
  };
  const hideModal = () => { backdrop.classList.remove('show'); modal.classList.remove('show'); };

  openBtns.forEach(btn => btn.addEventListener('click', showModal));
  closeBtns.forEach(btn => btn.addEventListener('click', hideModal));
  backdrop.addEventListener('click', hideModal);

  // Timer: 20s
  setTimeout(showModal, 20000);
  // Scroll depth: 50%
  window.addEventListener('scroll', function() {
    const scrolled = window.scrollY + window.innerHeight;
    const perc = scrolled / document.documentElement.scrollHeight;
    if (perc > 0.5) { showModal(); window.removeEventListener('scroll', arguments.callee); }
  });
  // Exit intent
  document.addEventListener('mouseout', function(e) {
    if (e.clientY <= 0) showModal();
  });
})();

// Simple client-side validation & submit simulation
(function() {
  const form = document.querySelector('#leadForm');
  const status = document.querySelector('#leadStatus');
  if (!form) return;
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    // Basic checks
    const name = form.querySelector('[name="name"]').value.trim();
    const email = form.querySelector('[name="email"]').value.trim();
    const phone = form.querySelector('[name="phone"]').value.trim();
    const course = form.querySelector('[name="course"]').value;
    if (!name || !email || !phone || !course) {
      status.textContent = 'Please fill all required fields.';
      status.className = 'text-red-400 mt-2';
      return;
    }
    // Simulate success
    status.textContent = 'Thanks! Our counsellor will reach out shortly.';
    status.className = 'text-emerald-400 mt-2';
    setTimeout(() => {
      document.querySelector('#leadBackdrop').classList.remove('show');
      document.querySelector('#leadModal').classList.remove('show');
      form.reset();
    }, 1500);
  });
})();

// Cookie consent (DPDP compliant notice)
(function(){
  const banner = document.querySelector('#cookieBanner');
  const accBtn = document.querySelector('#cookieAccept');
  if (!banner) return;
  const key = 'openpath_cookie_ok';
  if (!localStorage.getItem(key)) banner.classList.add('show');
  accBtn && accBtn.addEventListener('click', function(){
    localStorage.setItem(key, '1');
    banner.classList.remove('show');
  });
})();
